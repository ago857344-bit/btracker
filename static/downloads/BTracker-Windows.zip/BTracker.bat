@echo off
set "SCRIPT_DIR=%~dp0"
if exist "%SCRIPT_DIR%index.html" (
    start "" msedge --app="%SCRIPT_DIR%index.html" 2>nul || start "" chrome --app="%SCRIPT_DIR%index.html" 2>nul || start "" "%SCRIPT_DIR%index.html"
) else (
    start "" msedge --app="https://btracker.app/welcome" 2>nul || start "" "https://btracker.app/welcome"
)
