BTracker — JEE Study Command Center for Windows
=================================================
1. Double-click BTracker.vbs (silent windowless launcher) or BTracker.bat.
2. It launches BTracker in standalone app mode (without browser tabs/address bar).
3. You can right-click BTracker.vbs -> "Send to Desktop (create shortcut)" or Pin to Start/Taskbar.
