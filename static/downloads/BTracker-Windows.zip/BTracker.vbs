Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
currentDir = fso.GetParentFolderName(WScript.ScriptFullName)
indexPath = currentDir & "\index.html"

If fso.FileExists(indexPath) Then
    WshShell.Run "cmd /c start msedge --app=""" & indexPath & """", 0
Else
    WshShell.Run "cmd /c start msedge --app=https://btracker.app/welcome", 0
End If
Set WshShell = Nothing
